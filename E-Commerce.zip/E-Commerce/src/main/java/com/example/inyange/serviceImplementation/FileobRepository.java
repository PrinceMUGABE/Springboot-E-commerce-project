package com.example.inyange.serviceImplementation;

public class FileobRepository {
}

package com.example.inyange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InyangeDistributorApplicationTests {

    @Test
    void contextLoads() {
    }

}
